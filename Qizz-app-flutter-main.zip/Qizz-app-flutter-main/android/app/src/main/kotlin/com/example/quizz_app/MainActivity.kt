package com.example.quizz_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
