package com.example.micard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
