package com.example.dicee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
